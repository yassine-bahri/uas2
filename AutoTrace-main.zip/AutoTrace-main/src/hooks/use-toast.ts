
// Re-export from components/ui/use-toast.ts
import { useToast, toast } from "@/components/ui/use-toast";

export { useToast, toast };
