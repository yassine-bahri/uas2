
// Re-export the supabase client from the integrations folder
import { supabase } from '@/integrations/supabase/client';

export { supabase };
